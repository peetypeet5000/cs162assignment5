Name: Peter LaMontagne
Id: 933-338-880

I implimented all the standard requirements of the Linked List and nothing more.
The driver file does have a nice selection system so you should be able to test all
of it without commenting/modifiying the code.

None of the extra credit was attempted.